import json, urllib.request, os

NEF_URL = os.environ["NEF_SERVICE_URL"]

def handler(event, context):
    method  = event["httpMethod"]
    path    = event["path"]
    body    = event.get("body", "")
    headers = event.get("headers", {}) or {}

    url = NEF_URL.rstrip("/") + path
    req = urllib.request.Request(
        url, data=body.encode() if body else None,
        headers={k: v for k, v in headers.items()
                 if k.lower() in ("authorization", "content-type")},
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            return {
                "statusCode": resp.status,
                "headers": {"Content-Type": "application/json"},
                "body": resp.read().decode(),
            }
    except urllib.error.HTTPError as e:
        return {
            "statusCode": e.code,
            "headers": {"Content-Type": "application/json"},
            "body": e.read().decode(),
        }
    except Exception as exc:
        return {
            "statusCode": 502,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"error": str(exc)}),
        }
